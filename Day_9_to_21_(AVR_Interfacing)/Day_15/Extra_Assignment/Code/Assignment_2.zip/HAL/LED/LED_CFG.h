#ifndef LED_CFG_H_
#define LED_CFG_H_

#define LED_SINGLE_ON 1
#define LED_SINGLE_OFF 0

#define LED_ARRAY_ON 0xFF
#define LED_ARRAY_OFF 0x00


#endif