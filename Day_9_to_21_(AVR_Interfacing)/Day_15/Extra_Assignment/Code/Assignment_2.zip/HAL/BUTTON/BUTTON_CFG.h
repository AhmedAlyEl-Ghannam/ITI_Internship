#ifndef BUTTON_CFG_H_
#define BUTTON_CFG_H_

#define BTN_PRESSED 1
#define BTN_RELEASED 0

#endif