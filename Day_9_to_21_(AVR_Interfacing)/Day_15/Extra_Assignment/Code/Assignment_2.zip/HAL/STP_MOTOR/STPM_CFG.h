#ifndef STPM_CFG_H_
#define STPM_CFG_H_

#define STPM_PORT 						DIO_PORTD
#define STPM_COIL_BLUE_PIN     			DIO_PIN0
#define STPM_COIL_PINK_PIN     			DIO_PIN1
#define STPM_COIL_YELLOW_PIN   			DIO_PIN2
#define STPM_COIL_ORANGE_PIN   			DIO_PIN3

#endif