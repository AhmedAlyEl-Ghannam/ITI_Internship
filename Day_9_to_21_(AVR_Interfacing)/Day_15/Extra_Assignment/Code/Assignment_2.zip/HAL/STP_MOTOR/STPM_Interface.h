#ifndef STPM_INTERFACE_H_
#define STPM_INTERFACE_H_

void STPM_voidInitMotor(void);
void STPM_voidRotateCW(void);
void STPM_voidRotateACW(void);
//void STPM_voidSetMotorSpeed(u8 copy_u8MotorSpeed); // this will be delayed until I write PWM Shenanigans

#endif