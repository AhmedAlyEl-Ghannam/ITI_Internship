#ifndef SS_INTERFACE_H_
#define SS_INTERFACE_H_

void SS_voidSevenSegInit(u8 copy_u8PortName);
void SS_voidDisplayNumber(u8 copy_u8PortName, u8 copy_u8Number);


#endif